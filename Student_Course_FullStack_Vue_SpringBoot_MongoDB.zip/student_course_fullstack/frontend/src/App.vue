<template>
  <main class="container">
    <h1>Student Management System</h1>
    <form @submit.prevent="saveStudent" class="form">
      <input v-model.trim="studentForm.name" placeholder="Name" required>
      <input v-model.trim="studentForm.department" placeholder="Department" required>
      <input v-model.trim="studentForm.email" type="email" placeholder="Email" required>
      <button type="submit">{{ studentEditingId !== null ? 'Update Student' : 'Add Student' }}</button>
      <button type="button" class="secondary" @click="resetStudent">Clear</button>
    </form>
    <h2>Search Student</h2>
    <div class="form">
      <input v-model.trim="search" placeholder="Enter exact student name">
      <button type="button" @click="searchStudent">Search</button>
      <button type="button" class="secondary" @click="loadStudents">Show All</button>
    </div>
    <h2>Student List</h2>
    <p v-if="students.length === 0" class="empty">No students to display.</p>
    <div v-for="s in students" :key="s.id" class="record">
      <div><strong>{{ s.name }}</strong><span>{{ s.department }} · {{ s.email }}</span></div>
      <div class="actions"><button type="button" @click="editStudent(s)">Edit</button><button type="button" class="danger" @click="deleteStudent(s.id)">Delete</button></div>
    </div>
    <hr>
    <h1>Course Management System</h1>
    <form @submit.prevent="saveCourse" class="form">
      <input v-model.trim="courseForm.courseName" placeholder="Course Name" required>
      <input v-model.trim="courseForm.courseCode" placeholder="Course Code" required>
      <input v-model.number="courseForm.duration" type="number" min="1" placeholder="Duration (months)" required>
      <button type="submit">{{ courseEditingId !== null ? 'Update Course' : 'Add Course' }}</button>
      <button type="button" class="secondary" @click="resetCourse">Clear</button>
    </form>
    <h2>Course List</h2>
    <p v-if="courses.length === 0" class="empty">No courses to display.</p>
    <div v-for="c in courses" :key="c.id" class="record">
      <div><strong>{{ c.courseName }}</strong><span>{{ c.courseCode }} · {{ c.duration }} month(s)</span></div>
      <div class="actions"><button type="button" @click="editCourse(c)">Edit</button><button type="button" class="danger" @click="deleteCourse(c.id)">Delete</button></div>
    </div>
    <p v-if="message" class="message">{{ message }}</p>
  </main>
</template>

<script>
const API = 'http://localhost:8080';
export default {
  data() {
    return {
      students: [], courses: [],
      studentForm: { name: '', department: '', email: '' }, studentEditingId: null,
      courseForm: { courseName: '', courseCode: '', duration: 1 }, courseEditingId: null,
      search: '', message: ''
    };
  },
  methods: {
    async loadStudents() {
      try {
        const r = await fetch(`${API}/students`);
        if (!r.ok) throw new Error();
        this.students = await r.json(); this.message = '';
      } catch { this.message = 'Could not load students. Check backend and MongoDB.'; }
    },
    async loadCourses() {
      try {
        const r = await fetch(`${API}/courses`);
        if (!r.ok) throw new Error();
        this.courses = await r.json();
      } catch { this.message = 'Could not load courses. Check backend and MongoDB.'; }
    },
    async searchStudent() {
      if (!this.search) { this.message = 'Enter a student name to search.'; return; }
      try {
        const r = await fetch(`${API}/students/search?name=${encodeURIComponent(this.search)}`);
        if (r.ok) { this.students = [await r.json()]; this.message = ''; }
        else { this.students = []; this.message = 'Student not found.'; }
      } catch { this.message = 'Search failed. Check backend connection.'; }
    },
    async saveStudent() {
      const edit = this.studentEditingId !== null;
      try {
        const r = await fetch(edit ? `${API}/students/${this.studentEditingId}` : `${API}/students`, {
          method: edit ? 'PUT' : 'POST', headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(this.studentForm)
        });
        if (!r.ok) throw new Error();
        this.message = 'Student saved successfully.'; this.resetStudent(); await this.loadStudents();
      } catch { this.message = 'Could not save student.'; }
    },
    editStudent(s) { this.studentForm = {name:s.name, department:s.department, email:s.email}; this.studentEditingId = s.id; },
    async deleteStudent(id) {
      if (!confirm('Delete this student?')) return;
      try {
        const r = await fetch(`${API}/students/${id}`, {method:'DELETE'});
        if (!r.ok) throw new Error();
        this.message = 'Student deleted successfully.'; await this.loadStudents();
      } catch { this.message = 'Could not delete student.'; }
    },
    resetStudent() { this.studentForm = {name:'', department:'', email:''}; this.studentEditingId = null; },
    async saveCourse() {
      const edit = this.courseEditingId !== null;
      try {
        const r = await fetch(edit ? `${API}/courses/${this.courseEditingId}` : `${API}/courses`, {
          method: edit ? 'PUT' : 'POST', headers: {'Content-Type':'application/json'},
          body: JSON.stringify(this.courseForm)
        });
        if (!r.ok) throw new Error();
        this.message = 'Course saved successfully.'; this.resetCourse(); await this.loadCourses();
      } catch { this.message = 'Could not save course.'; }
    },
    editCourse(c) { this.courseForm = {courseName:c.courseName, courseCode:c.courseCode, duration:c.duration}; this.courseEditingId = c.id; },
    async deleteCourse(id) {
      if (!confirm('Delete this course?')) return;
      try {
        const r = await fetch(`${API}/courses/${id}`, {method:'DELETE'});
        if (!r.ok) throw new Error();
        this.message = 'Course deleted successfully.'; await this.loadCourses();
      } catch { this.message = 'Could not delete course.'; }
    },
    resetCourse() { this.courseForm = {courseName:'', courseCode:'', duration:1}; this.courseEditingId = null; }
  },
  mounted() { this.loadStudents(); this.loadCourses(); }
};
</script>
