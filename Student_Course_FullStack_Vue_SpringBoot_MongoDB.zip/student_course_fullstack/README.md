# Student + Course Management (Vue + Spring Boot + MongoDB)

Requirements: Java 17+, Maven, Node.js/npm, MongoDB on localhost:27017.

Backend: open `backend/`, run `mvn spring-boot:run`.
Frontend: open `frontend/`, run `npm install` then `npm run dev`.
Open the Vite URL, normally http://localhost:5173.

MongoDB database: `college_db`; collections: `students`, `courses`.
Student features: add, list, edit, delete, exact-name search.
Course features: add, list, edit, delete.
See API endpoints in the backend controllers. Students and courses are independent collections; enrollment relationships are not implemented.
