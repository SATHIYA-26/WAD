package com.example.demo;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "courses")
public class Course {
  @Id private String id;
  private String courseName;
  private String courseCode;
  private int duration;
  public Course() {}
  public String getId() { return id; }
  public void setId(String id) { this.id = id; }
  public String getCourseName() { return courseName; }
  public void setCourseName(String courseName) { this.courseName = courseName; }
  public String getCourseCode() { return courseCode; }
  public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
  public int getDuration() { return duration; }
  public void setDuration(int duration) { this.duration = duration; }
}
