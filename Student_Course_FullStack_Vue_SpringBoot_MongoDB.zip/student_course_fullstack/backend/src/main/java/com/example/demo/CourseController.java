package com.example.demo;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/courses")
@CrossOrigin(origins = "http://localhost:5173")
public class CourseController {
  private final CourseRepository repo;
  public CourseController(CourseRepository repo) { this.repo = repo; }
  @PostMapping public Course add(@RequestBody Course c) { c.setId(null); return repo.save(c); }
  @GetMapping public List<Course> getAll() { return repo.findAll(); }
  @GetMapping("/{id}") public ResponseEntity<Course> getOne(@PathVariable String id) {
    return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
  }
  @PutMapping("/{id}") public ResponseEntity<Course> update(@PathVariable String id, @RequestBody Course c) {
    if (!repo.existsById(id)) return ResponseEntity.notFound().build();
    c.setId(id); return ResponseEntity.ok(repo.save(c));
  }
  @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable String id) {
    if (!repo.existsById(id)) return ResponseEntity.notFound().build();
    repo.deleteById(id); return ResponseEntity.noContent().build();
  }
}
