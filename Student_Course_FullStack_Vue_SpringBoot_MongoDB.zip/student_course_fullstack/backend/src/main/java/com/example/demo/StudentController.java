package com.example.demo;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "http://localhost:5173")
public class StudentController {
  private final StudentRepository repo;
  public StudentController(StudentRepository repo) { this.repo = repo; }
  @PostMapping public Student add(@RequestBody Student s) { s.setId(null); return repo.save(s); }
  @GetMapping public List<Student> getAll() { return repo.findAll(); }
  @GetMapping("/{id}") public ResponseEntity<Student> getOne(@PathVariable String id) {
    return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
  }
  @GetMapping("/search") public ResponseEntity<Student> search(@RequestParam String name) {
    return repo.findByNameIgnoreCase(name).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
  }
  @PutMapping("/{id}") public ResponseEntity<Student> update(@PathVariable String id, @RequestBody Student s) {
    if (!repo.existsById(id)) return ResponseEntity.notFound().build();
    s.setId(id); return ResponseEntity.ok(repo.save(s));
  }
  @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable String id) {
    if (!repo.existsById(id)) return ResponseEntity.notFound().build();
    repo.deleteById(id); return ResponseEntity.noContent().build();
  }
}
