Servlet Marks and Grade Calculator
Uses javax.servlet, suitable for Tomcat 9.

Files:
- index.html
- src/MarksServlet.java
- WEB-INF/web.xml

Run:
1. Copy this folder into Tomcat's webapps folder.
2. Compile the servlet into WEB-INF/classes using Tomcat's servlet-api.jar:
   javac -cp "C:\apache-tomcat-9.0.xx\lib\servlet-api.jar" -d WEB-INF/classes src\MarksServlet.java
   Change the Tomcat path to your installation path.
3. Start Tomcat.
4. Open http://localhost:8080/Servlet_Marks_Project/index.html

The form uses POST and the servlet implements doPost().
