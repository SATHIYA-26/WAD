import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MarksServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("name");
        int marks = Integer.parseInt(request.getParameter("marks"));

        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Student Result</h2>");
        response.getWriter().println("<p>Name: " + name + "</p>");
        response.getWriter().println("<p>Marks: " + marks + "</p>");

        if (marks < 0 || marks > 100) {
            response.getWriter().println("<p>Invalid marks. Enter 0 to 100.</p>");
        } else if (marks >= 90) {
            response.getWriter().println("<p>Grade: A</p>");
        } else if (marks >= 75) {
            response.getWriter().println("<p>Grade: B</p>");
        } else if (marks >= 50) {
            response.getWriter().println("<p>Grade: C</p>");
        } else {
            response.getWriter().println("<p>Result: Fail</p>");
        }

        response.getWriter().println("<p><a href='index.html'>Back</a></p>");
        response.getWriter().println("</body></html>");
    }
}
