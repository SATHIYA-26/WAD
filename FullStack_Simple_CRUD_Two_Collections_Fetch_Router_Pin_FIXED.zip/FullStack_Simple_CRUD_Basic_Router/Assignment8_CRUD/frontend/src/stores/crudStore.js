import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useCrudStore = defineStore('crud', () => {
  const items = ref([])
  const message = ref('')

  async function read(url) {
    const response = await fetch(url)
    items.value = await response.json()
  }

  async function create(url, data) {
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    message.value = 'Created successfully.'
  }

  async function update(url, data) {
    await fetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    message.value = 'Updated successfully.'
  }

  async function remove(url) {
    await fetch(url, { method: 'DELETE' })
    message.value = 'Deleted successfully.'
  }

  return { items, message, read, create, update, remove }
})
