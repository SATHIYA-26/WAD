<script setup>
import { onMounted } from 'vue'
import { useCrudStore } from '../stores/crudStore'
const store = useCrudStore()
onMounted(() => store.read('/api/students'))
</script>

<template>
  <section>
    <h2>Read Students</h2>
    <table border="1" cellpadding="6">
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Age</th></tr></thead>
      <tbody>
        <tr v-for="item in store.items" :key="item.id"><td>{{ item.id }}</td><td>{{ item.name }}</td><td>{{ item.email }}</td><td>{{ item.age }}</td></tr>
      </tbody>
    </table>
  </section>
</template>
