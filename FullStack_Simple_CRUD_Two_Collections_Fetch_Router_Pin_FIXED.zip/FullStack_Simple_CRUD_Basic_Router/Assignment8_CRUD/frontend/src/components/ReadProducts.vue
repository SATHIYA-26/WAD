<script setup>
import { onMounted } from 'vue'
import { useCrudStore } from '../stores/crudStore'
const store = useCrudStore()
onMounted(() => store.read('/api/products'))
</script>

<template>
  <section>
    <h2>Read Products</h2>
    <table border="1" cellpadding="6">
      <thead><tr><th>ID</th><th>Name</th><th>Price</th><th>Quantity</th></tr></thead>
      <tbody>
        <tr v-for="item in store.items" :key="item.id"><td>{{ item.id }}</td><td>{{ item.name }}</td><td>{{ item.price }}</td><td>{{ item.quantity }}</td></tr>
      </tbody>
    </table>
  </section>
</template>
