<script setup>
import { ref } from 'vue'
import { useCrudStore } from '../stores/crudStore'
const store = useCrudStore()
const name = ref('')
const email = ref('')
const age = ref('')

async function submit() {
  await store.create('/api/students', {
      name: name.value,
      email: email.value,
      age: Number(age.value)
  })
  name.value = ''
  email.value = ''
  age.value = ''
 }
</script>

<template>
  <section>
    <h2>Create Student</h2>
    <form @submit.prevent="submit">
      <p><label>Name: <input v-model="name" type="text" required></label></p>
      <p><label>Email: <input v-model="email" type="text" required></label></p>
      <p><label>Age: <input v-model="age" type="number" required></label></p>
      <button type="submit">Create</button>
    </form>
    <p>{{ store.message }}</p>
  </section>
</template>
