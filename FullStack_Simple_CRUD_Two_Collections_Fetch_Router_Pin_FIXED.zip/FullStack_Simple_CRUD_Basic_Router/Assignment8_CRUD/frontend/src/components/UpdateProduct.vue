<script setup>
import { ref } from 'vue'
import { useCrudStore } from '../stores/crudStore'
const store = useCrudStore()
const id = ref('')
const name = ref('')
const price = ref('')
const quantity = ref('')

async function submit() {
  await store.update('/api/products/' + id.value, {
      id: id.value,
      name: name.value,
      price: Number(price.value),
      quantity: Number(quantity.value)
  })
}
</script>

<template>
  <section>
    <h2>Update Product</h2>
    <form @submit.prevent="submit">
      <p><label>ID: <input v-model="id" required></label></p>
      <p><label>Name: <input v-model="name" type="text" required></label></p>
      <p><label>Price: <input v-model="price" type="number" step="0.01" required></label></p>
      <p><label>Quantity: <input v-model="quantity" type="number" required></label></p>
      <button type="submit">Update</button>
    </form>
    <p>{{ store.message }}</p>
  </section>
</template>
