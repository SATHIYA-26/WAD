<script setup>
import { ref } from 'vue'
import { useCrudStore } from '../stores/crudStore'
const store = useCrudStore()
const id = ref('')
async function submit() {
  await store.remove('/api/students/' + id.value)
  id.value = ''
}
</script>

<template>
  <section>
    <h2>Delete Student</h2>
    <form @submit.prevent="submit">
      <label>ID: <input v-model="id" required></label>
      <button type="submit">Delete</button>
    </form>
    <p>{{ store.message }}</p>
  </section>
</template>
