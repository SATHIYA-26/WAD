package com.example.college.service;

import com.example.college.model.Student;
import com.example.college.repository.StudentRepository;
import java.util.List;
import org.bson.Document;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public List<Student> getAll() {
        return repository.findAll();
    }

    public Student create(Student student) {
        return repository.save(student);
    }

    public Student update(String id, Student student) {
        student.setId(id);
        return repository.save(student);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

    public List<Document> getStudentsWithCourses() {
        return repository.getStudentsWithCourses();
    }
}
