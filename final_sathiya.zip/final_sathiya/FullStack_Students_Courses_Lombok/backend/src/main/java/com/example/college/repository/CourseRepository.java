package com.example.college.repository;
import com.example.college.model.Course;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface CourseRepository extends MongoRepository<Course, String> {}
