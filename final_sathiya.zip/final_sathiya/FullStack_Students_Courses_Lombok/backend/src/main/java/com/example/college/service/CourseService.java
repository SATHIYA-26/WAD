package com.example.college.service;

import com.example.college.model.Course;
import com.example.college.repository.CourseRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
    private final CourseRepository repository;

    public CourseService(CourseRepository repository) {
        this.repository = repository;
    }

    public List<Course> getAll() {
        return repository.findAll();
    }

    public Course create(Course course) {
        return repository.save(course);
    }

    public Course update(String id, Course course) {
        course.setId(id);
        return repository.save(course);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}
