package com.example.college.repository;

import com.example.college.model.Student;
import java.util.List;
import org.bson.Document;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface StudentRepository extends MongoRepository<Student, String> {

    @Aggregation(pipeline = {
        "{ '$lookup': { 'from': 'courses', 'localField': 'courseId', 'foreignField': 'courseId', 'as': 'courseDetails' } }"
    })
    List<Document> getStudentsWithCourses();
}
