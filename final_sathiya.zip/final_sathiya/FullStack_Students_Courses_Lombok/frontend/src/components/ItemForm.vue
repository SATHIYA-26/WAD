<script setup>
import {ref} from 'vue'
const props=defineProps({kind:{type:String,required:true},buttonText:{type:String,default:'Add'}})
const emit=defineEmits(['submit'])
const a=ref(''),b=ref(''),c=ref(''),courseId=ref('')
function submitForm(){
 if(props.kind==='student') emit('submit',{name:a.value,email:b.value,age:Number(c.value),courseId:courseId.value})
 else emit('submit',{title:a.value,instructor:b.value,credits:Number(c.value),courseId:courseId.value})
 a.value='';b.value='';c.value='';courseId.value=''
}
</script>
<template><form class="form" @submit.prevent="submitForm">
<input v-model="a" :placeholder="kind==='student'?'Student name':'Course title'" required>
<input v-model="b" :placeholder="kind==='student'?'Email':'Instructor'" required>
<input v-model="c" type="number" min="0" :placeholder="kind==='student'?'Age':'Credits'" required>
<input v-model="courseId" placeholder="Shared Course ID (e.g. C101)" required>
<button>{{buttonText}}</button></form></template>
