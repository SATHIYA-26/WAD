import {defineStore} from 'pinia'
export const useCollegeStore=defineStore('college',{
 state:()=>({students:[],courses:[],joinedStudents:[],message:''}),
 actions:{
  async request(url,method='GET',data){
   const options={method,headers:{'Content-Type':'application/json'}}
   if(data!==undefined) options.body=JSON.stringify(data)
   const r=await fetch(url,options)
   if(!r.ok) throw new Error('Request failed. Check backend, MongoDB, and record ID.')
   return r.status===204?null:r.json()
  },
  async loadStudents(){this.students=await this.request('/api/students')},
  async loadJoinedStudents(){this.joinedStudents=await this.request('/api/students/with-courses')},
  async addStudent(s){await this.request('/api/students','POST',s);this.message='Student added!';await this.loadStudents()},
  async updateStudent(id,s){await this.request('/api/students/'+id,'PUT',s);this.message='Student updated!';await this.loadStudents()},
  async deleteStudent(id){await this.request('/api/students/'+id,'DELETE');this.message='Student deleted!';await this.loadStudents()},
  async loadCourses(){this.courses=await this.request('/api/courses')},
  async addCourse(c){await this.request('/api/courses','POST',c);this.message='Course added!';await this.loadCourses()},
  async updateCourse(id,c){await this.request('/api/courses/'+id,'PUT',c);this.message='Course updated!';await this.loadCourses()},
  async deleteCourse(id){await this.request('/api/courses/'+id,'DELETE');this.message='Course deleted!';await this.loadCourses()}
 }
})