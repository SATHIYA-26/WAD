<script setup>
import {onMounted,ref} from 'vue'
import {useCollegeStore} from '../stores/collegeStore'
import ItemForm from '../components/ItemForm.vue'
const store=useCollegeStore(), error=ref('')
const id=ref(''),title=ref(''),instructor=ref(''),credits=ref(''),courseId=ref(''),deleteId=ref('')
async function run(fn){try{error.value='';await fn()}catch(e){error.value=e.message}}
onMounted(()=>run(()=>store.loadCourses()))
</script>
<template><section><h2>Courses</h2>
<h3>Add course</h3><ItemForm kind="course" button-text="Add Course" @submit="c=>run(()=>store.addCourse(c))"/>
<h3>Update course</h3><form class="form" @submit.prevent="run(()=>store.updateCourse(id,{title,instructor,credits:Number(credits),courseId}))">
<input v-model="id" placeholder="Course ID" required><input v-model="title" placeholder="New title" required><input v-model="instructor" placeholder="New instructor" required><input v-model="credits" type="number" min="0" placeholder="New credits" required><input v-model="courseId" placeholder="Course ID (e.g. C101)" required><button>Update</button></form>
<h3>Delete course</h3><form class="form" @submit.prevent="run(()=>store.deleteCourse(deleteId))"><input v-model="deleteId" placeholder="Course ID" required><button class="danger">Delete</button></form>
<p class="message">{{store.message}}</p><p class="error" v-if="error">{{error}}</p>
<h3>All courses</h3><button @click="run(()=>store.loadCourses())">Refresh</button><div class="table-wrap"><table><thead><tr><th>ID</th><th>Title</th><th>Instructor</th><th>Credits</th><th>Course ID</th></tr></thead><tbody><tr v-for="c in store.courses" :key="c.id"><td class="id">{{c.id}}</td><td>{{c.title}}</td><td>{{c.instructor}}</td><td>{{c.credits}}</td><td>{{c.courseId}}</td></tr><tr v-if="!store.courses.length"><td colspan="5">No courses yet</td></tr></tbody></table></div></section></template>