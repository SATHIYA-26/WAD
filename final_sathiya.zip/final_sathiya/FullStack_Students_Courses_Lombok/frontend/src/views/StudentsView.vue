<script setup>
import {onMounted,ref} from 'vue'
import {useCollegeStore} from '../stores/collegeStore'
import ItemForm from '../components/ItemForm.vue'
const store=useCollegeStore(), error=ref('')
const id=ref(''),name=ref(''),email=ref(''),age=ref(''),courseId=ref(''),deleteId=ref('')
async function run(fn){try{error.value='';await fn()}catch(e){error.value=e.message}}
onMounted(()=>run(()=>store.loadStudents()))
</script>
<template><section><h2>Students</h2>
<h3>Add student</h3><ItemForm kind="student" button-text="Add Student" @submit="s=>run(()=>store.addStudent(s))"/>
<h3>Update student</h3><form class="form" @submit.prevent="run(()=>store.updateStudent(id,{name,email,age:Number(age),courseId}))">
<input v-model="id" placeholder="Student ID" required><input v-model="name" placeholder="New name" required><input v-model="email" type="email" placeholder="New email" required><input v-model="age" type="number" min="0" placeholder="New age" required><input v-model="courseId" placeholder="Course ID (e.g. C101)" required><button>Update</button></form>
<h3>Delete student</h3><form class="form" @submit.prevent="run(()=>store.deleteStudent(deleteId))"><input v-model="deleteId" placeholder="Student ID" required><button class="danger">Delete</button></form>
<p class="message">{{store.message}}</p><p class="error" v-if="error">{{error}}</p>
<h3>All students</h3><button @click="run(()=>store.loadStudents())">Refresh</button><div class="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Age</th><th>Course ID</th></tr></thead><tbody><tr v-for="s in store.students" :key="s.id"><td class="id">{{s.id}}</td><td>{{s.name}}</td><td>{{s.email}}</td><td>{{s.age}}</td><td>{{s.courseId}}</td></tr><tr v-if="!store.students.length"><td colspan="5">No students yet</td></tr></tbody></table></div><h3>Students with course details (Aggregation)</h3><button @click="run(async()=>{await store.loadJoinedStudents()})">Load Joined Data</button><div class="table-wrap"><table><thead><tr><th>Student</th><th>Course ID</th><th>Course Details</th></tr></thead><tbody><tr v-for="s in store.joinedStudents" :key="s._id"><td>{{s.name}}</td><td>{{s.courseId}}</td><td>{{s.courseDetails?.map(c=>c.title + ' (' + c.instructor + ')').join(', ') || 'No matching course'}}</td></tr><tr v-if="!store.joinedStudents.length"><td colspan="3">Click Load Joined Data</td></tr></tbody></table></div></section></template>