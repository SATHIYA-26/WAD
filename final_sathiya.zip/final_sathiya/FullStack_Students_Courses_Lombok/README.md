# Full Stack Students + Courses CRUD (Lombok @Data)

Backend structure:
- `model/`: Student.java, Course.java (uses Lombok `@Data`)
- `repository/`: StudentRepository.java, CourseRepository.java
- `service/`: StudentService.java, CourseService.java
- `controller/`: StudentController.java, CourseController.java

Stack: Vue 3, Vue Router, Pinia, Spring Boot, Spring Data MongoDB, Lombok.
Database: `college_db`; collections: `students`, `courses`.

## Requirements
- JDK 17+
- Maven
- Node.js
- MongoDB running at `mongodb://127.0.0.1:27017`
- IDE Lombok support is recommended (VS Code Java extensions/Lombok support).

## Run
1. Start MongoDB.
2. In terminal 1: `cd backend` then `mvn spring-boot:run`
3. In terminal 2: `cd frontend` then `npm install` then `npm run dev`
4. Open the Vite URL, usually `http://localhost:5173`.

## Lombok
`@Data` generates getters, setters, `toString`, `equals`, and `hashCode` at compile time. The Lombok dependency is included in `backend/pom.xml`.


CORS is configured directly on StudentController and CourseController using @CrossOrigin. There is no separate CorsConfig.java file.


## MongoDB Aggregation: Students + Courses
The project includes a `$lookup` aggregation endpoint: `GET /api/students/with-courses`. It joins the `students` and `courses` collections using the shared `courseId` field. When adding a student and a course, enter the same Course ID (for example, `C101`) in both forms. On the Students page, click **Load Joined Data** to view the aggregation result.

The frontend uses Vue Router, Pinia, and `fetch()`. CORS is configured with `@CrossOrigin` on the controllers; there is no separate `CorsConfig.java`.
