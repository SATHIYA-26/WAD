# 2 Shopping Billing Calculator

Files: `index.html`, `style.css`, `script.js`

Features: Product selection, quantity, subtotal, discount, and final amount.

Run by opening `index.html` in a browser. No installation required.
