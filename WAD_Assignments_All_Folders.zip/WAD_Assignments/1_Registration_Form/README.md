# 1 Registration Form

Files: `index.html`, `style.css`, `script.js`

Features: Registration fields, required validation, event dropdown, fee calculation, submitted details.

Run by opening `index.html` in a browser. No installation required.
