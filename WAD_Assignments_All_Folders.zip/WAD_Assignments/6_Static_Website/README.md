# 6 Static Website

Files: `index.html`, `style.css`

Features: Symposium information, navigation links, event cards, schedule table, and contact link.

Run by opening `index.html` in a browser. No installation required.
