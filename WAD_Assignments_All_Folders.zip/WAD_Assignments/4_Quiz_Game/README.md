# 4 Quiz Game

Files: `index.html`, `style.css`, `script.js`

Features: Multiple-choice questions, click events, conditions, score calculation, and restart.

Run by opening `index.html` in a browser. No installation required.
