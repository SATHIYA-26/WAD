# 5 Calculator

Files: `index.html`, `style.css`, `script.js`

Features: Five-subject total, average, grade, and pass/fail calculation.

Run by opening `index.html` in a browser. No installation required.
