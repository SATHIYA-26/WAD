# 3 Record Management

Files: `index.html`, `style.css`, `script.js`

Features: Add records, display table, search records, and delete records.

Run by opening `index.html` in a browser. No installation required.
